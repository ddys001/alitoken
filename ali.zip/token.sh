CURRENT_DIR=$(cd $(dirname $0); pwd)
token=$(cat $CURRENT_DIR/token.txt)
tklen=${#token}
if [ "$tklen" == 32 ]; then
ntoken=$(curl https://auth.aliyundrive.com/v2/account/token -X POST -H "User-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.83 Safari/537.36" -H "Rererer:https://www.aliyundrive.com/" -H "Content-Type:application/json" -d '{"refresh_token":"'$token'", "grant_type": "refresh_token"}'| sed 's/,/\n/g' | grep refresh_token | cut -d \: -f2 | sed 's/"//g')
else
ntoken=''
fi
echo  -n ${ntoken} > $CURRENT_DIR/token.txt
cp -r token.txt html/token.txt