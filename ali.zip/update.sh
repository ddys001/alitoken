#!/bin/bash
. /etc/profile

# 本机 Nginx 版本
NGINX_VERSION_OLD=$(cat nginx-ver)
# 最新 Nginx 版本
NGINX_VERSION=$(wget -qO- --no-check-certificate https://github.com/nginx/nginx/tags |grep release-|head -n 1|awk '{print $7}'|cut -d \- -f4|cut -d \< -f1)
# 检查更新
if [ "$NGINX_VERSION_OLD" == "$NGINX_VERSION" ]; then
  echo "当前Nginx为最新版$NGINX_VERSION" 
  exit
fi

# 创建编译工作目录
homepath=$(pwd)
mkdir -p $homepath/nginx-build
cd $homepath/nginx-build

# 下载 Nginx 源码
rm $homepath/nginx
echo -n $NGINX_VERSION > $homepath/nginx-ver
wget http://nginx.org/download/nginx-${NGINX_VERSION}.tar.gz
tar -xzvf nginx-${NGINX_VERSION}.tar.gz

# 配置编译参数
cd nginx-${NGINX_VERSION}
./configure --prefix=/tmp/local/nginx --with-stream --with-mail --user=runner --group=runner --with-http_ssl_module --with-http_auth_request_module --with-pcre --http-log-path=/tmp/local/nginx/logs/access.log
# 开始编译
make

# 更新 Nginx
mv $homepath/nginx-build/nginx-${NGINX_VERSION}/objs/nginx $homepath/nginx
rm -rf $homepath/nginx-build